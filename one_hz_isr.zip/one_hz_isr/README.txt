Decription one_hz_interrupt
This Assembly-language program shows how to employ a 1 Hz interrupt by taking advantage of the Timer-registers embedded on the microcontroller.  