/*
 * knight_rider.c
 *
 * Created: 16/11/2021 23:50:48
 * Author : Antoine van Meeteren 
 * Practicum: Microcontroller programmeren in C 
 */ 

#include <avr/io.h>
#include <stdint.h>
#include <stdlib.h> 
#define f_cpu 3686400UL
#include  <avr/interrupt.h>

/*function to toggle and configure TC1 in Compare mode with register 1b*/ 
void toggle_TC1_OCR1B_COMP(void) {
	unsigned static int normal_mode_tccr1A = 0x00;
	unsigned static int mode_tccr1b_prescaler1024_ctc_on = 0b00001101;
	unsigned static int max_count = 0x0383;
	 cli(); 
	 TCCR1A = normal_mode_tccr1A;
	 TCCR1B = mode_tccr1b_prescaler1024_ctc_on;  /*toggle prescaler to 1024 and mode to CTC*/
	 OCR1B = max_count; //set OUTPUT-COMPARE-REGISTER-B equal to the max count value specified for this progam
	 TCNT1 = 0x0000; //value of tcnt1 to 0 
	 TIMSK |= 1<<OCIE1B; /*toggle on the Output-Compare Interrupt Flag so this could work*/ 
	 sei(); 
}
ISR (TIMER1_COMPB_vect) {
	
	
	
	unsigned static int i = 0;
	unsigned static int data_array[4] = {0x7e, 0xbd, 0xdb, 0xe7};
	unsigned static int display_data = 0;
	unsigned static int *hex_value_ptr;
	unsigned static int array_cursor = 0;

		if (i < 4) {
			hex_value_ptr = &data_array[array_cursor]; /*if we are not at the 4th adres; read data from left*/ /*point to the first memory address of the data_array to retrieve the data*/
			array_cursor++; /*increment array_cursor to next adres*/ 
			display_data = *hex_value_ptr; 
			PORTB = display_data;
		}
			/*if we have reached the 4th adres; read data from right-to-left until 1st adres is reached*/ 
		else {
			--array_cursor; 
			 hex_value_ptr = &data_array[array_cursor];/*if we are not at the 4th adres; read data from left*/ /*point to the first memory address of the data_array to retrieve the data*/
			display_data = *hex_value_ptr;
			PORTB = display_data;
		} 
			i++;
				if (i >= 8) {
					i = 0; //start again at 0 after looping through the array 1x counting up and 1x counting down 
				}
				
	TCNT1 = 0x0000; //Set timer-counter1 back to 0 to start again 
	sei();	//interrupts are enabled again 
}

int main(void)
{	

	
		unsigned static int normal_mode_tccr1A = 0x00;
	unsigned static int mode_tccr1b_prescaler1024_ctc_on = 0b00001101;
	unsigned static int max_count = 0x0383;
	 cli(); 
	 TCCR1A = normal_mode_tccr1A;
	 TCCR1B = mode_tccr1b_prescaler1024_ctc_on;  /*toggle prescaler to 1024 and mode to CTC*/
	 OCR1B = max_count; //set OUTPUT-COMPARE-REGISTER-B equal to the max count value specified for this progam
	 TCNT1 = 0x0000; //value of tcnt1 to 0 
	 TIMSK |= 1<<OCIE1B; /*toggle on the Output-Compare Interrupt Flag so this could work*/ 
	 sei(); 
	
		while(1) {
		
		DDRB = 0XFF; //toggle leds on portb as output 
	}
	return 0; 
}

